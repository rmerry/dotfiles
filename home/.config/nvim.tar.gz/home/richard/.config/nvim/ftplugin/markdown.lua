vim.opt.nu = false
vim.opt.relativenumber = false

vim.opt.wrap = true
vim.opt.linebreak = true

vim.opt.spell = true
