return {
 	'echasnovski/mini.nvim',
 	name = 'mini.align',
	priority = 1000,
}
